import {hotMocha} from './mock_data';
alert(hotMocha);