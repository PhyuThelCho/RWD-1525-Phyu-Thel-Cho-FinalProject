// var hotLatte ={
//     ItemID: "R001",
//     ItemName: hotLatte,
//     IsAvailable: "Available",
//     Price: "MMK4000"
// };


export const hotMocha =['R002', 'HotMocha', 'Available', 'MMK3500'];
// export const hotAmericano =[R003, 'HotAmericano', 'Available', 'MMK4500'];
// export const hotCapuccino =[R003, 'HotCapuccino', 'Available', 'MMK4000'];